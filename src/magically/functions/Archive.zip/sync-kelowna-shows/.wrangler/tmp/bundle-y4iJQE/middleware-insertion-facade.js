				import worker, * as OTHER_EXPORTS from "/Users/mzaheer/Downloads/90078f0c-0421-4a37-a484-5132d5f6ae7a/src/magically/functions/sync-kelowna-shows/index.ts";
				import * as __MIDDLEWARE_0__ from "/Users/mzaheer/.npm/_npx/32026684e21afda6/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "/Users/mzaheer/.npm/_npx/32026684e21afda6/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts";

				export * from "/Users/mzaheer/Downloads/90078f0c-0421-4a37-a484-5132d5f6ae7a/src/magically/functions/sync-kelowna-shows/index.ts";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;